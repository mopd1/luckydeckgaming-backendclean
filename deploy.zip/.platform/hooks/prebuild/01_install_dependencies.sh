#!/bin/bash
cd /var/app/staging
echo "Installing dependencies..."
npm install
