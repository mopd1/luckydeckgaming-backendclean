#!/bin/bash
cd /var/app/staging
echo "Installing ioredis and other dependencies..."
npm install ioredis
npm install
