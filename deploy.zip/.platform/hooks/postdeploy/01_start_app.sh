#!/bin/bash
echo "Starting Node.js application with npm start..."
