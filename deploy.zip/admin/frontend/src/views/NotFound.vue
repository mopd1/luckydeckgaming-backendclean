<template>
  <div class="not-found">
    <h1 class="text-h4 mb-6">404 - Page Not Found</h1>
    <p>The page you're looking for doesn't exist or has been moved.</p>
    <v-btn color="primary" to="/" class="mt-4">Return to Dashboard</v-btn>
  </div>
</template>

<script setup>
// No script logic needed for this component
</script>
