<template>
  <div>
    <h1 class="text-h4 mb-6">SQL Query</h1>
    <p>SQL query interface will be implemented here</p>
  </div>
</template>

<script setup>
// Implementation will be added later
</script>
